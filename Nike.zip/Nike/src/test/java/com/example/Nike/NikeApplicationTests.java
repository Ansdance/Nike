package com.example.Nike;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NikeApplicationTests {

	@Test
	void contextLoads() {
	}

}
